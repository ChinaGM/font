此项目不再维护。
请转到商业版：https://www.centos.bz/2014/06/new-http-guard-release/
